<template lang="pug">
  .cart-footer
</template>

<script>
  export default {
    name: 'CartFooter',
  };
</script>

<style scoped lang="scss"></style>
