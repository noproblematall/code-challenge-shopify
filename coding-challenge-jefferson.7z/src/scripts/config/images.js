/* eslint import/prefer-default-export: "off" */

// TODO: generate URL for assets/loader.gif
export const loading = '';
