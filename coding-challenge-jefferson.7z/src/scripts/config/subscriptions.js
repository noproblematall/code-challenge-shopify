export const purchaseTypeSingle = 'single';
export const purchaseTypeRecurring = 'recurring';
