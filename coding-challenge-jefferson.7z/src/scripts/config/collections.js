/* eslint import/prefer-default-export: "off" */

export const allProductsHandle = 'all-products';
