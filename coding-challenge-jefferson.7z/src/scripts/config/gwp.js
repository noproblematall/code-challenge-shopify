// add more here as we beef up GWP
export const gwpTypes = {
  threshold: 'threshold',
};

// add more here as we beef up GWP
export const gwpStorageCancelledKeys = {
  threshold: 'gwp_threshold_cancelled',
};
