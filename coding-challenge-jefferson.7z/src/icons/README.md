
# Icons

Place SVG files in this directory to automatically add them to the icon store.

### Tips

- Before exporting, simplify shapes as much as possible. Ideally, you will have a single path per separate shape in the icon
- After exporting, eliminate some items from the SVGs XML
  - static width/height
  - fill colors (this will allow you to control color through CSS fill property)
  - group elements
